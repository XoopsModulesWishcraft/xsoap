<?

$adminmenu[1]['title'] = 'Configure Tables';
$adminmenu[1]['link'] = "admin/index.php?op=tables";
$adminmenu[2]['title'] = 'Configure Fields';
$adminmenu[2]['link'] = "admin/index.php?op=fields";
$adminmenu[3]['title'] = 'Configure Views';
$adminmenu[3]['link'] = "admin/index.php?op=views";
$adminmenu[4]['title'] = 'Configure Plugins';
$adminmenu[4]['link'] = "admin/index.php?op=plugins";
$adminmenu[5]['title'] = 'Permissions';
$adminmenu[5]['link'] = "admin/permissions.php";
?>