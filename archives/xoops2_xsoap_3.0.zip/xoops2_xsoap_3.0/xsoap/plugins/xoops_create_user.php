<?

	include(XOOPS_ROOT_PATH.'/modules/xsoap/plugins/inc/usercheck.php');	
	include(XOOPS_ROOT_PATH.'/class/xoopsmailer.php');
	include(XOOPS_ROOT_PATH.'/class/xoopsuser.php');
	
	function xoops_create_user_xsd(){
		$xsd = array();
		$i=0;
		$xsd['request'][$i] = array("name" => "username", "type" => "string");
		$xsd['request'][$i++] = array("name" => "password", "type" => "string");	
		$data = array();
			$data[] = array("name" => "user_viewemail", "type" => "integer");
			$data[] = array("name" => "uname", "type" => "string");		
			$data[] = array("name" => "email", "type" => "string");
			$data[] = array("name" => "url", "type" => "string");		
			$data[] = array("name" => "actkey", "type" => "string");
			$data[] = array("name" => "pass", "type" => "string");
			$data[] = array("name" => "timezone_offset", "type" => "string");
			$data[] = array("name" => "user_mailok", "type" => "integer");		
		$xsd['request'][$i++]['items']['data'] = $data;
		$xsd['request'][$i++]['items']['objname'] = 'auth';
		
		$i=0;
		$xsd['response'][$i] = array("name" => "ERRNUM", "type" => "integer");
		$data = array();
			$data[] = array("name" => "id", "type" => "integer");
			$data[] = array("name" => "user", "type" => "string");		
			$data[] = array("name" => "text", "type" => "string");
		$i++;
		$xsd['response'][$i]['items']['data'] = $data;
		$xsd['response'][$i]['items']['objname'] = 'RESULT';
		
		return $xsd;
	}
	
	function xoops_create_user_wsdl(){
	
	}
	
	function xoops_create_user_wsdl_service(){
	
	}
	
	function xoops_create_user($username, $password, $user)
	{	

		global $xoopsModuleConfig, $xoopsConfig;
		if ($xoopsModuleConfig['site_user_auth']==1){
			if (!checkright(basename(__FILE__),$username,$password))
				return array('ErrNum'=> 9, "ErrDesc" => 'No Permission for plug-in');
		}

		if ($user['passhash']!=''){
			if ($user['passhash']!=sha1(($user['time']-$user['rand']).$user['uname'].$user['pass']))
				return array("ERRNUM" => 4, "ERRTXT" => 'No Passhash');
		} else {
			return array("ERRNUM" => 4, "ERRTXT" => 'No Passhash');
		}
		
		foreach($user as $k => $l){
			${$k} = $l;
		}
		
		if (strlen(userCheck($uname, $email, $pass, $pass))==0){

			global $xoopsConfig;
			$config_handler =& xoops_gethandler('config');
			$xoopsConfigUser =& $config_handler->getConfigsByCat(XOOPS_CONF_USER);
			
			$member_handler =& xoops_gethandler('member');
			$newuser =& $member_handler->createUser();
			$newuser->setVar('user_viewemail',$user_viewemail, true);
			$newuser->setVar('uname', $uname, true);
			$newuser->setVar('email', $email, true);
			if ($url != '') {
				$newuser->setVar('url', formatURL($url), true);
			}
			$newuser->setVar('user_avatar','blank.gif', true);

			if (empty($actkey)||strlen($actkey)>5)
				$actkey = substr(md5(uniqid(mt_rand(), 1)), 0, 8);
				
			$newuser->setVar('actkey', $actkey, true);
			$newuser->setVar('pass', md5($pass), true);
			$newuser->setVar('timezone_offset', $timezone_offset, true);
			$newuser->setVar('user_regdate', time(), true);
			$newuser->setVar('uorder',$xoopsConfig['com_order'], true);
			$newuser->setVar('umode',$xoopsConfig['com_mode'], true);
			$newuser->setVar('user_mailok',$user_mailok, true);
			$newuser->setVar('user_intrest',_US_USERREG.' @ '.$xoops_url, true);
			if ($xoopsConfigUser['activation_type'] == 1) {
				$newuser->setVar('level', 1, true);
			}
	
			if (!$member_handler->insertUser($newuser, true)) {
				$return = array('id' => 1, "text" => _US_REGISTERNG);
			} else {
				$newid = $newuser->getVar('uid');
				if (!$member_handler->addUserToGroup(XOOPS_GROUP_USERS, $newid)) {
					$return = array('id' => 1, "text" => _US_REGISTERNG);
				}
				if ($xoopsConfigUser['activation_type'] == 1) {
					$return = array('id' => 2,  "user" => $uname);
				}
				// Sending notification email to user for self activation
				if ($xoopsConfigUser['activation_type'] == 0) {
					if (!function_exists('getMailer'))
						$xoopsMailer =& xoops_getMailer();
					if (!function_exists('xoops_getMailer'))
						$xoopsMailer =& getMailer();
					$xoopsMailer->useMail();
					$xoopsMailer->setTemplate('register.tpl');
					$xoopsMailer->assign('SITENAME', $xoopsConfig['sitename']);
					$xoopsMailer->assign('ADMINMAIL', $xoopsConfig['adminmail']);
					$xoopsMailer->assign('SITEURL', XOOPS_URL."/");
					$xoopsMailer->setToUsers(new XoopsUser($newid));
					$xoopsMailer->setFromEmail($xoopsConfig['adminmail']);
					$xoopsMailer->setFromName($xoopsConfig['sitename']);
					$xoopsMailer->setSubject(sprintf(_US_USERKEYFOR, $uname));
					if ( !$xoopsMailer->send() ) {
						$return = array('id' => 1, "text" => _US_YOURREGMAILNG);
					} else {
						$return = array('id' => 1, "text" => _US_YOURREGISTERED);
					}
				// Sending notification email to administrator for activation
				} elseif ($xoopsConfigUser['activation_type'] == 2) {
					if (!function_exists('getMailer'))
						$xoopsMailer =& xoops_getMailer();
					if (!function_exists('xoops_getMailer'))
						$xoopsMailer =& getMailer();
					$xoopsMailer->useMail();
					$xoopsMailer->setTemplate('adminactivate.tpl');
					$xoopsMailer->assign('USERNAME', $uname);
					$xoopsMailer->assign('USEREMAIL', $email);
					$xoopsMailer->assign('USERACTLINK', XOOPS_URL.'/register.php?op=actv&id='.$newid.'&actkey='.$actkey);
					$xoopsMailer->assign('SITENAME', $xoopsConfig['sitename']);
					$xoopsMailer->assign('ADMINMAIL', $xoopsConfig['adminmail']);
					$xoopsMailer->assign('SITEURL', XOOPS_URL."/");
					$member_handler =& xoops_gethandler('member');
					$xoopsMailer->setToGroups($member_handler->getGroup($xoopsConfigUser['activation_group']));
					$xoopsMailer->setFromEmail($xoopsConfig['adminmail']);
					$xoopsMailer->setFromName($xoopsConfig['sitename']);
					$xoopsMailer->setSubject(sprintf(_US_USERKEYFOR, $uname));
					if ( !$xoopsMailer->send() ) {
						$return = array('id' => 1, "text" => _US_YOURREGMAILNG);
					} else {
						$return = array('id' => 1, "text" => _US_YOURREGISTERED2);
					}
				}
				if ($xoopsConfigUser['new_user_notify'] == 1 && !empty($xoopsConfigUser['new_user_notify_group'])) {
					if (!function_exists('getMailer'))
						$xoopsMailer =& xoops_getMailer();
					if (!function_exists('xoops_getMailer'))
						$xoopsMailer =& getMailer();
					$xoopsMailer->useMail();
					$member_handler =& xoops_gethandler('member');
					$xoopsMailer->setToGroups($member_handler->getGroup($xoopsConfigUser['new_user_notify_group']));
					$xoopsMailer->setFromEmail($xoopsConfig['adminmail']);
					$xoopsMailer->setFromName($xoopsConfig['sitename']);
					$xoopsMailer->setSubject(sprintf(_US_NEWUSERREGAT,$xoopsConfig['sitename']));
					$xoopsMailer->setBody(sprintf(_US_HASJUSTREG, $uname));
					$xoopsMailer->send();
				}
			}
					
			return array("ERRNUM" => 1, "RESULT" => $return);
		
		} else {

			return array("ERRNUM" => 1, "RESULT" => array('id' => 1, 'text' => userCheck($uname, $email, $pass, $pass)));

		}				

	}

?>