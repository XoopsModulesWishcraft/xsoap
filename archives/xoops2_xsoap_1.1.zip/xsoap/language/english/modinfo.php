<?php
	define('_X_SOAP_WDSL','Allow WDSL Soap Server');
	define('_X_SOAP_WDSLDESC','Turn on and off WDSL Services');
	define('_X_SOAP_USERAUTH','Requires Username');
	define('_X_SOAP_USERAUTHDESC','Only Allows Site Users to use services');
?>
