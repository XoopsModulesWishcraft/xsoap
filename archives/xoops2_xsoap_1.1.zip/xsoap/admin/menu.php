<?

$adminmenu[1]['title'] = 'Configure Tables';
$adminmenu[1]['link'] = "admin/index.php?op=tables";
$adminmenu[2]['title'] = 'Configure Fields';
$adminmenu[2]['link'] = "admin/index.php?op=fields";

?>